#Gives the user option for calculation operation
choice = input('''
Please select the type of operation you want to perform:
+ for addition
- for subtraction
* for multiplication
/ for division
% for modulo
''')
 #Asks the user to give number inputs
num_1 = int(input('Enter your first number: '))
num_2 = int(input('Enter your second number: '))

#Uses IfElse statements to select kind of operation based on inputs 
if choice == '+':
    print('{} + {} = '.format(num_1, num_2))
    print(num_1 + num_2)
 
elif choice == '-':
    print('{} - {} = '.format(num_1, num_2))
    print(num_1 - num_2)
 
elif choice == '*':
    print('{} * {} = '.format(num_1, num_2))
    print(num_1 * num_2)
 
elif choice == '/':
    print('{} / {} = '.format(num_1, num_2))
    print(num_1 / num_2)

elif choice == '%':
    print('{} % {} = '.format(num_1, num_2))
    print(num_1 % num_2)
 
else:
    print('Enter a valid operator then run the program again.')